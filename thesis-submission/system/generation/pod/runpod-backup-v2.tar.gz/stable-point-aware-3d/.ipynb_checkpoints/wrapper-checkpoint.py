# ref: phase4 A. loads spar3d once, serves mesh over http.
import io, os, tempfile
import torch
from PIL import Image
from flask import Flask, request, send_file
from transparent_background import Remover
from spar3d.system import SPAR3D
from spar3d.utils import foreground_crop, remove_background

DEVICE = "cuda"
FG_RATIO = 1.3
TEX_RES = 1024

print("loading spar3d...")
model = SPAR3D.from_pretrained(
    "stabilityai/stable-point-aware-3d",
    config_name="config.yaml",
    weight_name="model.safetensors",
    low_vram_mode=False,
)
model.to(DEVICE)
model.eval()
bg_remover = Remover(device=DEVICE)
print("model resident. ready.")

app = Flask(__name__)

@app.route("/health")
def health():
    return {"status": "ok"}

@app.route("/generate", methods=["POST"])
def generate():
    img = Image.open(io.BytesIO(request.data)).convert("RGBA")
    img = remove_background(img, bg_remover)
    img = foreground_crop(img, FG_RATIO)
    with torch.no_grad():
        with torch.autocast(device_type=DEVICE, dtype=torch.bfloat16):
            mesh, _ = model.run_image(
                [img],
                bake_resolution=TEX_RES,
                remesh="none",
                vertex_count=-1,
                return_points=True,
            )
    out = os.path.join(tempfile.mkdtemp(), "mesh.glb")
    mesh.export(out, include_normals=True)
    return send_file(out, mimetype="model/gltf-binary", download_name="mesh.glb")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000)